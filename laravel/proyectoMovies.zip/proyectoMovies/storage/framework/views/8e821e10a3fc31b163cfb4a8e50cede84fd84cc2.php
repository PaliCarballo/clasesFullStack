<?php
        foreach($actors as $actor){
            echo $actor->getFullName().'<br>';
        }

        ?><?php /**PATH /var/www/html/carpetaPersonal/PalomaCarballo/laravel/proyectoMovies/resources/views/actors/index.blade.php ENDPATH**/ ?>