<?php
        foreach($actors as $actor){
            echo $actor->getFullName().'<br>';
        }

        ?>