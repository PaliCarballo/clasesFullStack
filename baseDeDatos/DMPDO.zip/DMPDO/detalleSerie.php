<?php
    require('conexion.php');

    //preparo y ejecuto la consulta de las series
    $query = $conex->prepare('SELECT * FROM series');
    $query->execute();

    $resultado = $query->fetch(PDO::FETCH_ASSOC);

    //preparo la consulta de seasons
    $queryTemporada = $conex->prepare('SELECT * FROM seasons WHERE serie_id = ?');
    $temporadas = $query->fetch(PDO::FETCH_ASSOC);

    //var_dump($resultado); exit;

    require_once('plantilla/header.php');
    require_once('plantilla/menu.php');
 ?>
    <section class="principal">
        <article class="nuevas" id="series">
            <div class="peliculas">
            <h2><?php echo $resultado['title'] ?></h2>
            <div class="">
                Fecha de estreno:<?php echo $resultado['release_date'] ?>
            </div>
            <div class="">
                Fecha de finalización:<?php echo $resultado['end_date'] ?>
            </div>
            <div class="">
                Genre:<?php echo $resultado['genre_id'] ?>
            </div>

            </div>

            <ul>
                <?php
                    foreach ($temporadas as $temporada) {
                        //me traigo el genero de esta peli
                        if(isset($temporada['serie_id']))
                        {
                        $queryTemporada->execute([ $temporada['serie_id'] ]);
                        $genero = $queryTemporada->fetch(PDO::FETCH_ASSOC);
                        $nombreTemporada = $genero['name'];
                        } else
                        {
                            $nombreTemporada = 'Sin Temporada';
                        }
                        //imprimo el titulo de la peli y su genero
                        echo '<a href="detallePelicula.php?id='.$temporada['serie_id'].'"><li>'.$temporada['title'].' ('.$nombreTemporada.')</li></a>';
                        }
                ?>
            </ul>
        </article>

    </section>
</div>

<?php require_once('plantilla/footer.php'); ?>

